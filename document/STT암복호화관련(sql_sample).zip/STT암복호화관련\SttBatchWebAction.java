package xcron.com.webaction;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;

import jedix.xwing.action.XwingWebAction;
import wfm.com.util.AES256Cipher;

import com.locus.jedi.biz.JediTransaction;
import com.locus.jedi.biz.JediTransactionManager;
import com.locus.jedi.log.IVRLogger;
import com.locus.jedi.service.sql.SQLParam;
import com.locus.jedi.service.sql.SQLServiceException;
import com.locus.jedi.service.sql.SQLServiceManager;
import com.locus.jedi.transfer.ListParam;
import com.locus.jedi.waf.action.WebActionException;
import com.locus.jedi.waf.controller.JediRequest;
import com.locus.jedi.waf.controller.JediResponse;

public class SttBatchWebAction extends XwingWebAction {
	/**
	 * STT 일괄 암/복호화 작업 배치 추가해야할 항목
	 * SttBatchWebAction.java 추가
	 * req_sample.xml, sql_sample.xml 추가 
	 * --> 중요!!!! sql_sample.xml에 msens.xcron.hansol.setbatchdecwebaction_1_sample, msens.xcron.hansol.setbatchencwebaction_1_sample의 
	 *     reg_date 기준을 변경하고 스케줄 돌려야됨!!, TOP 개수도 변경해서 돌릴것
	 * serviceconfig_msens.xml에 SVC_BATCH_01, SVC_BATCH_02를 추가하고, 스케줄(최대 3개)을 추가하면 됨
	 */
	private static final long serialVersionUID = 1L;
	final static String PROP_DIR = System.getProperty("jedi.home")+"/webapps/WEB-INF/conf.properties";
	private String key = "";
    private String sdate = "";
    private String edate = "";
    
	public void perform(JediRequest req, JediResponse res) throws WebActionException {
		IVRLogger.error("SttBatchWebAction Start!!");
		
		String type = req.param.getString("type");
		sdate = req.param.getString("sdate","");
		edate = req.param.getString("edate","");
		
		if(sdate != null || !"".equals(sdate)) sdate = sdate + "000000";
		if(edate != null || !"".equals(edate)) edate = edate + "235959";
		
		Properties prop = new Properties();
		FileInputStream fis;
		
		try {
			fis = new FileInputStream(PROP_DIR);
			prop.load(new java.io.BufferedInputStream(fis));
			key = prop.getProperty("cipher_key");
			//key256 = "LGUplus_1544ARS_WebService000001";
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		try {
			
			if("D".equals(type)){
				setSttDecrypt();
			}else if("E".equals(type)){
				setSttEncrypt();
			}
			
			IVRLogger.error("SttBatchWebAction Stop!!");
			
		} catch (Exception e) {
			e.getStackTrace();
			IVRLogger.error("#####SttBatchWebAction Error Message = "+e.getMessage());
			IVRLogger.error(e.getStackTrace());
		}
		
	}
	
	private void setSttDecrypt(){
		JediTransaction tran = JediTransactionManager.getJediTransaction();
		
	
		ListParam SttDecryptContent = new ListParam(new String[] {"UCID", "CONTENT"});
		ListParam DecryptRollback = null;
		ListParam SttDecryptSent = new ListParam(new String[] {"UCID", "STT_SENT_ID","STT_SENT"});
		
		try {
			IVRLogger.info("msens.xcron.hansol.setbatchdecwebaction_1_sample");
			//모든 데이터 Decrypt 시키면서 ENC_FLAG = 'Y'로 변경
			
			SQLParam sqlParam = new SQLParam();
			sqlParam.setSqlName("msens.xcron.hansol.setbatchdecwebaction_1_sample");
			sqlParam.addValue("sdate", sdate);
			sqlParam.addValue("edate", edate);
			SQLParam sqlResult = SQLServiceManager.getInstance().execute(sqlParam);
			
			DecryptRollback = sqlResult.getListParam("msens.xcron.hansol.setbatchdecwebaction_1_sample");
			
			IVRLogger.info("msens.xcron.hansol.setbatchdecwebaction_1_sample::sqlResult.getCount()::" + sqlResult.getCount());
		
			AES256Cipher aes_cipher = AES256Cipher.getInstance(key); 

			if(sqlResult.getCount() > 0){
				
				tran.begin();
				
				//enc_flag를 S로 업데이트
				SQLParam sqlParam2 = new SQLParam();
				sqlParam2.setSqlName("msens.xcron.hansol.setbatchdecwebaction_2_sample");
				sqlParam2.addValue("SttDecryptContent", DecryptRollback);
				
				SQLServiceManager.getInstance().execute(sqlParam2, tran);
				
				
				tran.commit();
				
				tran.begin();
				
				for(int i =0; i< sqlResult.getCount(); i++){
					
					SttDecryptContent.clear();
					SttDecryptSent.clear();
					
					IVRLogger.debug(sqlResult.getListParam("msens.xcron.hansol.setbatchdecwebaction_1_sample").getParam(i).getString("UCID"));
					
					String v_content = sqlResult.getListParam("msens.xcron.hansol.setbatchdecwebaction_1_sample").getParam(i).getString("CONTENT");
					//String dec_content = aes_cipher.decrypt(v_content);
					
					SttDecryptContent.addRow(new Object[] {
							sqlResult.getListParam("msens.xcron.hansol.setbatchdecwebaction_1_sample").getParam(i).getString("UCID"),
							v_content //dec_content
					});
	
					//IVRLogger.debug("#################RSLT 복호화 영역 진입");
						
					String ucid = sqlResult.getListParam("msens.xcron.hansol.setbatchdecwebaction_1_sample").getParam(i).getString("UCID");
					SQLParam sqlParam3 = new SQLParam();
					sqlParam3.setSqlName("msens.xcron.hansol.setbatchdecwebaction_rslt_1_sample");
					sqlParam3.addValue("ucid", ucid);
					SQLParam sqlResult3 = SQLServiceManager.getInstance().execute(sqlParam3);
						
					if(sqlResult3.getCount() > 0){
						for(int j=0; j< sqlResult3.getCount(); j++){
							String v_sent = sqlResult3.getListParam("msens.xcron.hansol.setbatchdecwebaction_rslt_1_sample").getParam(j).getString("STT_SENT");
							String dec_sent = aes_cipher.decrypt(v_sent);
								
							SttDecryptSent.addRow(new Object[] {
										sqlResult3.getListParam("msens.xcron.hansol.setbatchdecwebaction_rslt_1_sample").getParam(j).getString("UCID"),
										sqlResult3.getListParam("msens.xcron.hansol.setbatchdecwebaction_rslt_1_sample").getParam(j).getString("STT_SENT_ID"),
										dec_sent
							});
								
						}
					}	
					

					SQLParam sqlParam4 = new SQLParam();
					
					if(SttDecryptSent.rowSize()>0){
						IVRLogger.info("msens.xcron.hansol.setbatchdecwebaction_rslt_2_sample :: count ::" + SttDecryptSent.rowSize());
						
						sqlParam4.setSqlName("msens.xcron.hansol.setbatchdecwebaction_rslt_2_sample");
						sqlParam4.addValue("SttDecryptSent", SttDecryptSent);
						
						SQLServiceManager.getInstance().execute(sqlParam4, tran);
			
					}
	
					if(SttDecryptContent.rowSize()>0){
							IVRLogger.info("msens.xcron.hansol.setbatchdecwebaction_3_sample :: count ::" + SttDecryptContent.rowSize());
							
							sqlParam4.clear();
							sqlParam4.setSqlName("msens.xcron.hansol.setbatchdecwebaction_3_sample");
							sqlParam4.addValue("SttDecryptContent", SttDecryptContent);
							
							SQLServiceManager.getInstance().execute(sqlParam4, tran);
				
					}
	
				}
				
				tran.commit();
			}

		
		} catch (Exception e) {
			tran.rollback();
			
			if(DecryptRollback != null){
				if(DecryptRollback.rowSize() > 0){
					
					try {
						tran.begin();
						
						//에러난 경우 flag = 'N'으로 다시 변경
						//msens.xcron.hansol.setscriptresultwebaction_12
						SQLParam sqlParam5 =  new SQLParam();  
						sqlParam5.setSqlName("msens.xcron.hansol.setbatchdecwebaction_4_sample");
						sqlParam5.addValue("DecryptRollback", DecryptRollback);
						SQLServiceManager.getInstance().execute(sqlParam5, tran);
						
						tran.commit();
					} catch (SQLServiceException e1) {
						// TODO Auto-generated catch block
						tran.rollback();
						e1.printStackTrace();
					}
									
				}
			}
			
			e.getStackTrace();
			IVRLogger.error("#####SttBatchWebAction Decrypt Error Message = "+e.getMessage());
			IVRLogger.error(e.getStackTrace());
		}
		
	}
	
	private void setSttEncrypt(){
		JediTransaction tran = JediTransactionManager.getJediTransaction();
		
		
		ListParam SttEnctyptContent = new ListParam(new String[] {"UCID", "CONTENT"});
		ListParam SttEncryptSent = new ListParam(new String[] {"UCID", "STT_SENT_ID","STT_SENT"});
		ListParam EncryptRollback = null;
		
		try {
			IVRLogger.info("msens.xcron.hansol.setbatchencwebaction_1_sample");
			//모든 데이터 encrypt 시키면서 ENC_FLAG = 'Y'로 변경
			
			SQLParam sqlParam = new SQLParam();
			sqlParam.setSqlName("msens.xcron.hansol.setbatchencwebaction_1_sample");
			sqlParam.addValue("sdate", sdate);
			sqlParam.addValue("edate", edate);
			SQLParam sqlResult = SQLServiceManager.getInstance().execute(sqlParam);
			
			EncryptRollback = sqlResult.getListParam("msens.xcron.hansol.setbatchencwebaction_1_sample");
			
			IVRLogger.info("msens.xcron.hansol.setbatchencwebaction_1_sample::sqlResult.getCount()::" + sqlResult.getCount());
		
			AES256Cipher aes_cipher = AES256Cipher.getInstance(key); 

			if(sqlResult.getCount() > 0){
				
				tran.begin();
				
				//enc_flag를 S로 업데이트
				SQLParam sqlParam2 = new SQLParam();
				sqlParam2.setSqlName("msens.xcron.hansol.setbatchencwebaction_2_sample");
				sqlParam2.addValue("SttEnctyptContent", EncryptRollback);
				
				SQLServiceManager.getInstance().execute(sqlParam2, tran);
				
				tran.commit();
				

				tran.begin();
				
				for(int i =0; i< sqlResult.getCount(); i++){
					SttEnctyptContent.clear();
					SttEncryptSent.clear();
					
					IVRLogger.debug(sqlResult.getListParam("msens.xcron.hansol.setbatchencwebaction_1_sample").getParam(i).getString("UCID"));
					
					String v_content = sqlResult.getListParam("msens.xcron.hansol.setbatchencwebaction_1_sample").getParam(i).getString("CONTENT");
					String enc_content = aes_cipher.encrypt(v_content);
					
					SttEnctyptContent.addRow(new Object[] {
							sqlResult.getListParam("msens.xcron.hansol.setbatchencwebaction_1_sample").getParam(i).getString("UCID"),
							enc_content
					});
					
						
					String ucid = sqlResult.getListParam("msens.xcron.hansol.setbatchencwebaction_1_sample").getParam(i).getString("UCID");
					IVRLogger.debug("msens.xcron.hansol.setbatchencwebaction_rslt_1_sample START");
					
					SQLParam sqlParam3 = new SQLParam();
					sqlParam3.setSqlName("msens.xcron.hansol.setbatchencwebaction_rslt_1_sample");
					sqlParam3.addValue("ucid", ucid);
					SQLParam sqlResult3 = SQLServiceManager.getInstance().execute(sqlParam3);
					
					IVRLogger.debug("SQL3 COUNT =  "+ sqlResult3.getCount());
					if(sqlResult3.getCount() > 0){
						for(int j=0; j< sqlResult3.getCount(); j++){
							String v_sent = sqlResult3.getListParam("msens.xcron.hansol.setbatchencwebaction_rslt_1_sample").getParam(j).getString("STT_SENT");
							String enc_sent = aes_cipher.encrypt(v_sent);
								
							SttEncryptSent.addRow(new Object[] {
									sqlResult3.getListParam("msens.xcron.hansol.setbatchencwebaction_rslt_1_sample").getParam(j).getString("UCID"),
									sqlResult3.getListParam("msens.xcron.hansol.setbatchencwebaction_rslt_1_sample").getParam(j).getString("STT_SENT_ID"),
									enc_sent
							});
								
						}
					}	
					
					
					SQLParam sqlParam4 = new SQLParam();
						
					if(SttEncryptSent.rowSize()>0){
						IVRLogger.info("msens.xcron.hansol.setbatchencwebaction_rslt_2_sample :: count ::" + SttEncryptSent.rowSize());
						
						//sqlParam4.clear();
						sqlParam4.setSqlName("msens.xcron.hansol.setbatchencwebaction_rslt_2_sample");
						sqlParam4.addValue("SttEncryptSent", SttEncryptSent);
						
						SQLServiceManager.getInstance().execute(sqlParam4, tran);
			
					}
					
					if(SttEnctyptContent.rowSize()>0){
							IVRLogger.info("msens.xcron.hansol.setbatchencwebaction_3_sample :: count ::" + SttEnctyptContent.rowSize());
							
							sqlParam4.clear();
							sqlParam4.setSqlName("msens.xcron.hansol.setbatchencwebaction_3_sample");
							sqlParam4.addValue("SttEnctyptContent", SttEnctyptContent);
							
							SQLServiceManager.getInstance().execute(sqlParam4, tran);
				
					}
					
				
				}
				
				tran.commit();

			}

		
		} catch (Exception e) {
			tran.rollback();
			
			if(EncryptRollback != null){
				if(EncryptRollback.rowSize() > 0){
					
					try {
						tran.begin();
						
						//에러난 경우 flag = 'N'으로 다시 변경
						//msens.xcron.hansol.setscriptresultwebaction_12
						SQLParam sqlParam5 =  new SQLParam();  
						sqlParam5.setSqlName("msens.xcron.hansol.setbatchencwebaction_4_sample");
						sqlParam5.addValue("EncryptRollback", EncryptRollback);
						SQLServiceManager.getInstance().execute(sqlParam5, tran);
						
						tran.commit();
					} catch (SQLServiceException e1) {
						// TODO Auto-generated catch block
						tran.rollback();
						e1.printStackTrace();
					}
									
				}
			}
			
			e.getStackTrace();
			IVRLogger.error("#####SttBatchWebAction Encrypt Error Message = "+e.getMessage());
			IVRLogger.error(e.getStackTrace());
		}
	}
	
}

